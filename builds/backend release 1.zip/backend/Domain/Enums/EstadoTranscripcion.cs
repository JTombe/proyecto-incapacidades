namespace Incapacidades.Domain.Enums;

public enum EstadoTranscripcion
{
    Pendiente = 1,
    EnProceso = 2,
    Aceptada = 3,
    Rechazada = 4,
    Observada = 5
}

