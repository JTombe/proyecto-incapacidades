namespace Incapacidades.Domain.Enums;

public enum TipoDocumento
{
    Incapacidad = 1,
    Epicrisis = 2,
    FURIPS = 3,
    SoportePago = 4,
    HistoriaClinica = 5,
    Otro = 99
}

